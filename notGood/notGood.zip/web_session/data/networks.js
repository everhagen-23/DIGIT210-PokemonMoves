var networks = {"desc_output.tsv": {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.3",
  "target_cytoscapejs_version" : "~2.1",
  "data" : {
    "shared_name" : "desc_output.tsv",
    "name" : "desc_output.tsv",
    "SUID" : 155,
    "__Annotations" : [ ],
    "selected" : true
  },
  "elements" : {
    "nodes" : [ {
      "data" : {
        "id" : "1243",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Swaps every Pokémon's Defense and Special Defense for 5 turns.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Swaps every Pokémon's Defense and Special Defense for 5 turns.\"",
        "SelfLoops" : 0,
        "SUID" : 1243,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : -3742.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1241",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Protects the user's team from multi-target attacks.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Protects the user's team from multi-target attacks.\"",
        "SelfLoops" : 0,
        "SUID" : 1241,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : -3742.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1239",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Ignores opponent's Evasiveness for three turns, add Ground immunity.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Ignores opponent's Evasiveness for three turns, add Ground immunity.\"",
        "SelfLoops" : 0,
        "SUID" : 1239,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : -3742.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1237",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Changes the target's type to water.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Changes the target's type to water.\"",
        "SelfLoops" : 0,
        "SUID" : 1237,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : -3742.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1235",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Changes target's ability to Simple.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Changes target's ability to Simple.\"",
        "SelfLoops" : 0,
        "SUID" : 1235,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : -3742.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1233",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Raises user's Attack and sharply raises Speed.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Raises user's Attack and sharply raises Speed.\"",
        "SelfLoops" : 0,
        "SUID" : 1233,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : -3742.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1231",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Sharply raises user's Attack, Special Attack and Speed but lowers Defense and Special Defense.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Sharply raises user's Attack, Special Attack and Speed but lowers Defense and Special Defense.\"",
        "SelfLoops" : 0,
        "SUID" : 1231,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : -3742.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1229",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"User becomes the target's type.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"User becomes the target's type.\"",
        "SelfLoops" : 0,
        "SUID" : 1229,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : -3642.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1227",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Forces attacks to hit user, not team-mates.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Forces attacks to hit user, not team-mates.\"",
        "SelfLoops" : 0,
        "SUID" : 1227,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : -3642.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1225",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Raises user's Special Attack, Special Defense and Speed.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Raises user's Special Attack, Special Defense and Speed.\"",
        "SelfLoops" : 0,
        "SUID" : 1225,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : -3642.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1223",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Protects the user's team from high-priority moves.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Protects the user's team from high-priority moves.\"",
        "SelfLoops" : 0,
        "SUID" : 1223,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : -3642.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1221",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Makes the target act last this turn.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Makes the target act last this turn.\"",
        "SelfLoops" : 0,
        "SUID" : 1221,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : -3642.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1219",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Averages Attack and Special Attack with the target.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Averages Attack and Special Attack with the target.\"",
        "SelfLoops" : 0,
        "SUID" : 1219,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : -3642.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1217",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Suppresses the effects of held items for five turns.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Suppresses the effects of held items for five turns.\"",
        "SelfLoops" : 0,
        "SUID" : 1217,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : -3642.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1215",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Raises user's Attack and Accuracy.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Raises user's Attack and Accuracy.\"",
        "SelfLoops" : 0,
        "SUID" : 1215,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : -3542.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1213",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Restores half the target's max HP.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Restores half the target's max HP.\"",
        "SelfLoops" : 0,
        "SUID" : 1213,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : -3542.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1211",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Averages Defense and Special Defense with the target.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Averages Defense and Special Defense with the target.\"",
        "SelfLoops" : 0,
        "SUID" : 1211,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : -3542.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1209",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Makes target's ability same as user's.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Makes target's ability same as user's.\"",
        "SelfLoops" : 0,
        "SUID" : 1209,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : -3542.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1207",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Drastically raises user's Defense.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Drastically raises user's Defense.\"",
        "SelfLoops" : 0,
        "SUID" : 1207,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : -3542.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1205",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Raises user's Attack, Defense and Accuracy.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Raises user's Attack, Defense and Accuracy.\"",
        "SelfLoops" : 0,
        "SUID" : 1205,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : -3542.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1203",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Gives the user's held item to the target.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Gives the user's held item to the target.\"",
        "SelfLoops" : 0,
        "SUID" : 1203,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : -3542.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1201",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Reduces weight and sharply raises Speed.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Reduces weight and sharply raises Speed.\"",
        "SelfLoops" : 0,
        "SUID" : 1201,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : -3442.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1199",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"User switches with opposite teammate.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"User switches with opposite teammate.\"",
        "SelfLoops" : 0,
        "SUID" : 1199,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : -3442.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1197",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Gives target priority in the next turn.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Gives target priority in the next turn.\"",
        "SelfLoops" : 0,
        "SUID" : 1197,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : -3442.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1195",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Removes the effects of entry hazards and Substitute, and boosts user’s Attack and Speed.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Removes the effects of entry hazards and Substitute, and boosts user’s Attack and Speed.\"",
        "SelfLoops" : 0,
        "SUID" : 1195,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : -3442.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1193",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Harshly lowers the opponent's Defense and sharply raises their Attack.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Harshly lowers the opponent's Defense and sharply raises their Attack.\"",
        "SelfLoops" : 0,
        "SUID" : 1193,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : -3442.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1191",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Raises Defense of Ice types for 5 turns.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Raises Defense of Ice types for 5 turns.\"",
        "SelfLoops" : 0,
        "SUID" : 1191,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : -3442.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1189",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Protects the user and lowers opponent's Speed on contact.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Protects the user and lowers opponent's Speed on contact.\"",
        "SelfLoops" : 0,
        "SUID" : 1189,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : -3442.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1187",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Creates a substitute, then swaps places with a party Pokémon in waiting.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Creates a substitute, then swaps places with a party Pokémon in waiting.\"",
        "SelfLoops" : 0,
        "SUID" : 1187,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : -3342.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1185",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Revives a fainted party Pokémon to half HP.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Revives a fainted party Pokémon to half HP.\"",
        "SelfLoops" : 0,
        "SUID" : 1185,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : -3342.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1183",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Lowers HP but sharply boosts Attack, Special Attack, and Speed.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Lowers HP but sharply boosts Attack, Special Attack, and Speed.\"",
        "SelfLoops" : 0,
        "SUID" : 1183,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : -3342.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1181",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Changes the abilities of the user and its teammates to that of the target.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Changes the abilities of the user and its teammates to that of the target.\"",
        "SelfLoops" : 0,
        "SUID" : 1181,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : -3342.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1179",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Switches out and summons a snowstorm lasting 5 turns.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Switches out and summons a snowstorm lasting 5 turns.\"",
        "SelfLoops" : 0,
        "SUID" : 1179,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : -3342.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1177",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Raises Attack and Defense.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Raises Attack and Defense.\"",
        "SelfLoops" : 0,
        "SUID" : 1177,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : -3342.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1175",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Forces all Pokémon on the field to eat their berries.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Forces all Pokémon on the field to eat their berries.\"",
        "SelfLoops" : 0,
        "SUID" : 1175,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : -3342.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1173",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Lowers the opponent's Speed and makes them weaker to Fire-type moves.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Lowers the opponent's Speed and makes them weaker to Fire-type moves.\"",
        "SelfLoops" : 0,
        "SUID" : 1173,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : -3242.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1171",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Heals user's status conditions and raises its stats.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Heals user's status conditions and raises its stats.\"",
        "SelfLoops" : 0,
        "SUID" : 1171,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : -3242.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1169",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"The user eats its held Berry, then sharply raises its Defense stat.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"The user eats its held Berry, then sharply raises its Defense stat.\"",
        "SelfLoops" : 0,
        "SUID" : 1169,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : -3242.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1167",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Switches Attack and Defense stats.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Switches Attack and Defense stats.\"",
        "SelfLoops" : 0,
        "SUID" : 1167,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : -3242.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1165",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Lowers opponent's Defense and Special Defense every turn, and they cannot flee or switch out.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Lowers opponent's Defense and Special Defense every turn, and they cannot flee or switch out.\"",
        "SelfLoops" : 0,
        "SUID" : 1165,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : -3242.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1163",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Protects the user and sharply lowers Defence on contact.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Protects the user and sharply lowers Defence on contact.\"",
        "SelfLoops" : 0,
        "SUID" : 1163,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : -3242.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1161",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Raises all stats but user cannot switch out.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Raises all stats but user cannot switch out.\"",
        "SelfLoops" : 0,
        "SUID" : 1161,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : -3242.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1159",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Changes target's type to Psychic.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Changes target's type to Psychic.\"",
        "SelfLoops" : 0,
        "SUID" : 1159,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : -3142.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1157",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Heals user's status conditions and recovers HP.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Heals user's status conditions and recovers HP.\"",
        "SelfLoops" : 0,
        "SUID" : 1157,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : -3142.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1155",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"User and teammates recover HP.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"User and teammates recover HP.\"",
        "SelfLoops" : 0,
        "SUID" : 1155,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : -3142.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1153",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Restores team's HP and cures status conditions.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Restores team's HP and cures status conditions.\"",
        "SelfLoops" : 0,
        "SUID" : 1153,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : -3142.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1151",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Sharply raises target's Attack and Special Attack.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Sharply raises target's Attack and Special Attack.\"",
        "SelfLoops" : 0,
        "SUID" : 1151,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : -3142.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1149",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Swaps the effects on either side of the field.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Swaps the effects on either side of the field.\"",
        "SelfLoops" : 0,
        "SUID" : 1149,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : -3142.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1147",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Removes opponent's items.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Removes opponent's items.\"",
        "SelfLoops" : 0,
        "SUID" : 1147,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : -3142.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1145",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Boosts Attack and Defense of a teammate.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Boosts Attack and Defense of a teammate.\"",
        "SelfLoops" : 0,
        "SUID" : 1145,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : -3042.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1143",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Raises all user's stats but loses HP.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Raises all user's stats but loses HP.\"",
        "SelfLoops" : 0,
        "SUID" : 1143,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : -3042.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1141",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Changes the opponent's Ability to Insomnia.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Changes the opponent's Ability to Insomnia.\"",
        "SelfLoops" : 0,
        "SUID" : 1141,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : -3042.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1139",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Slower Pokémon move first in the turn for 5 turns.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Slower Pokémon move first in the turn for 5 turns.\"",
        "SelfLoops" : 0,
        "SUID" : 1139,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : -3042.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1137",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Poisons opponents switching into battle.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Poisons opponents switching into battle.\"",
        "SelfLoops" : 0,
        "SUID" : 1137,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : -3042.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1135",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Doubles Speed for 4 turns.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Doubles Speed for 4 turns.\"",
        "SelfLoops" : 0,
        "SUID" : 1135,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : -3042.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1133",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"User recovers half of its max HP and loses the Flying type temporarily.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"User recovers half of its max HP and loses the Flying type temporarily.\"",
        "SelfLoops" : 0,
        "SUID" : 1133,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : -3042.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1131",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Transfers user's status condition to the opponent.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Transfers user's status condition to the opponent.\"",
        "SelfLoops" : 0,
        "SUID" : 1131,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : -2942.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1129",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"User's own Attack and Defense switch.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"User's own Attack and Defense switch.\"",
        "SelfLoops" : 0,
        "SUID" : 1129,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : -2942.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1127",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"User and opponent swap Attack and Special Attack.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"User and opponent swap Attack and Special Attack.\"",
        "SelfLoops" : 0,
        "SUID" : 1127,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : -2942.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1125",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Sharply raises user's Special Attack.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Sharply raises user's Special Attack.\"",
        "SelfLoops" : 0,
        "SUID" : 1125,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : -2942.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1123",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Resets opponent's Evasiveness, removes Dark's Psychic immunity.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Resets opponent's Evasiveness, removes Dark's Psychic immunity.\"",
        "SelfLoops" : 0,
        "SUID" : 1123,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : -2942.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1121",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"User copies the opponent's attack with 1.5× power.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"User copies the opponent's attack with 1.5× power.\"",
        "SelfLoops" : 0,
        "SUID" : 1121,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : -2942.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1119",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"User becomes immune to Ground-type moves for 5 turns.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"User becomes immune to Ground-type moves for 5 turns.\"",
        "SelfLoops" : 0,
        "SUID" : 1119,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : -2942.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1117",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"The user faints but the next Pokémon released is fully healed.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"The user faints but the next Pokémon released is fully healed.\"",
        "SelfLoops" : 0,
        "SUID" : 1117,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : -2842.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1115",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Opponent cannot land critical hits for 5 turns.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Opponent cannot land critical hits for 5 turns.\"",
        "SelfLoops" : 0,
        "SUID" : 1115,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : -2842.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1113",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Stat changes are swapped with the opponent.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Stat changes are swapped with the opponent.\"",
        "SelfLoops" : 0,
        "SUID" : 1113,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : -2842.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1111",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"The user faints and the next Pokémon released is fully healed.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"The user faints and the next Pokémon released is fully healed.\"",
        "SelfLoops" : 0,
        "SUID" : 1111,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : -2842.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1109",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Prevents the opponent from restoring HP for 5 turns.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Prevents the opponent from restoring HP for 5 turns.\"",
        "SelfLoops" : 0,
        "SUID" : 1109,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : -2842.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1107",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"User and opponent swap Defense and Special Defense.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"User and opponent swap Defense and Special Defense.\"",
        "SelfLoops" : 0,
        "SUID" : 1107,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : -2842.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1105",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Prevents moves like Fly and Bounce and the Ability Levitate for 5 turns.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Prevents moves like Fly and Bounce and the Ability Levitate for 5 turns.\"",
        "SelfLoops" : 0,
        "SUID" : 1105,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : -2842.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1103",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Cancels out the effect of the opponent's Ability.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Cancels out the effect of the opponent's Ability.\"",
        "SelfLoops" : 0,
        "SUID" : 1103,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : -2742.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1101",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Opponent cannot use items.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Opponent cannot use items.\"",
        "SelfLoops" : 0,
        "SUID" : 1101,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : -2742.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1099",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Lowers opponent's Evasiveness and clears fog.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Lowers opponent's Evasiveness and clears fog.\"",
        "SelfLoops" : 0,
        "SUID" : 1099,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : -2742.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1097",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Puts all adjacent opponents to sleep.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Puts all adjacent opponents to sleep.\"",
        "SelfLoops" : 0,
        "SUID" : 1097,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : -2742.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1095",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Copies opponent's last move.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Copies opponent's last move.\"",
        "SelfLoops" : 0,
        "SUID" : 1095,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : -2742.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1093",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Sharply lowers opponent's Special Attack if opposite gender.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Sharply lowers opponent's Special Attack if opposite gender.\"",
        "SelfLoops" : 0,
        "SUID" : 1093,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : -2742.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1091",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Restores a little HP each turn.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Restores a little HP each turn.\"",
        "SelfLoops" : 0,
        "SUID" : 1091,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : -2742.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1089",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Sharply raises a random stat.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Sharply raises a random stat.\"",
        "SelfLoops" : 0,
        "SUID" : 1089,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : -2642.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1087",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Puts opponent to sleep in the next turn.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Puts opponent to sleep in the next turn.\"",
        "SelfLoops" : 0,
        "SUID" : 1087,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : -2642.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1085",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"The user recovers HP in the following turn.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"The user recovers HP in the following turn.\"",
        "SelfLoops" : 0,
        "SUID" : 1085,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : -2642.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1083",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Weakens the power of Fire-type moves.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Weakens the power of Fire-type moves.\"",
        "SelfLoops" : 0,
        "SUID" : 1083,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : -2642.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1081",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Swaps held items with the opponent.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Swaps held items with the opponent.\"",
        "SelfLoops" : 0,
        "SUID" : 1081,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : -2642.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1079",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Opponent cannot use the same move in a row.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Opponent cannot use the same move in a row.\"",
        "SelfLoops" : 0,
        "SUID" : 1079,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : -2642.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1077",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Lowers opponent's Attack and Defense.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Lowers opponent's Attack and Defense.\"",
        "SelfLoops" : 0,
        "SUID" : 1077,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : -2642.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1075",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Confuses all Pokémon.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Confuses all Pokémon.\"",
        "SelfLoops" : 0,
        "SUID" : 1075,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : -2542.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1073",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Opponent can only use moves that attack.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Opponent can only use moves that attack.\"",
        "SelfLoops" : 0,
        "SUID" : 1073,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : -2542.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1071",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Drastically raises user's Special Attack.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Drastically raises user's Special Attack.\"",
        "SelfLoops" : 0,
        "SUID" : 1071,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : -2542.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1069",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"The more times the user has performed Stockpile, the more HP is recovered.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"The more times the user has performed Stockpile, the more HP is recovered.\"",
        "SelfLoops" : 0,
        "SUID" : 1069,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : -2542.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1067",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Stores energy for use with Spit Up and Swallow.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Stores energy for use with Spit Up and Swallow.\"",
        "SelfLoops" : 0,
        "SUID" : 1067,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : -2542.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1065",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Steals the effects of the opponent's next move.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Steals the effects of the opponent's next move.\"",
        "SelfLoops" : 0,
        "SUID" : 1065,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : -2542.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1063",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"The user swaps Abilities with the opponent.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"The user swaps Abilities with the opponent.\"",
        "SelfLoops" : 0,
        "SUID" : 1063,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : -2542.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1061",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"User copies the opponent's Ability.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"User copies the opponent's Ability.\"",
        "SelfLoops" : 0,
        "SUID" : 1061,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : -2442.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1059",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Cures paralysis, poison, and burns.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Cures paralysis, poison, and burns.\"",
        "SelfLoops" : 0,
        "SUID" : 1059,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : -2442.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1057",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"User's used hold item is restored.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"User's used hold item is restored.\"",
        "SelfLoops" : 0,
        "SUID" : 1057,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : -2442.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1055",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Uses a certain move based on the current terrain.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Uses a certain move based on the current terrain.\"",
        "SelfLoops" : 0,
        "SUID" : 1055,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : -2442.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1053",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Weakens the power of Electric-type moves.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Weakens the power of Electric-type moves.\"",
        "SelfLoops" : 0,
        "SUID" : 1053,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : -2442.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1051",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"User faints, sharply lowers opponent's Attack and Special Attack.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"User faints, sharply lowers opponent's Attack and Special Attack.\"",
        "SelfLoops" : 0,
        "SUID" : 1051,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : -2442.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1049",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Reflects moves that cause status conditions back to the attacker.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Reflects moves that cause status conditions back to the attacker.\"",
        "SelfLoops" : 0,
        "SUID" : 1049,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : -2442.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1047",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"User restores HP each turn. User cannot escape/switch.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"User restores HP each turn. User cannot escape/switch.\"",
        "SelfLoops" : 0,
        "SUID" : 1047,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : -2342.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1045",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Opponent is unable to use moves that the user also knows.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Opponent is unable to use moves that the user also knows.\"",
        "SelfLoops" : 0,
        "SUID" : 1045,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : -2342.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1043",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Raises Attack of allies.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Raises Attack of allies.\"",
        "SelfLoops" : 0,
        "SUID" : 1043,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : -2342.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1041",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"In Double Battles, boosts the power of the partner's move.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"In Double Battles, boosts the power of the partner's move.\"",
        "SelfLoops" : 0,
        "SUID" : 1041,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : -2342.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1039",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Non-Ice types are damaged for 5 turns.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Non-Ice types are damaged for 5 turns.\"",
        "SelfLoops" : 0,
        "SUID" : 1039,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : -2342.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1037",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"If the users faints after using this move, the PP for the opponent's last move is depleted.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"If the users faints after using this move, the PP for the opponent's last move is depleted.\"",
        "SelfLoops" : 0,
        "SUID" : 1037,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : -2342.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1035",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"In Double Battle, the user takes all the attacks.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"In Double Battle, the user takes all the attacks.\"",
        "SelfLoops" : 0,
        "SUID" : 1035,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : -2342.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1033",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Confuses opponent, but raises its Special Attack.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Confuses opponent, but raises its Special Attack.\"",
        "SelfLoops" : 0,
        "SUID" : 1033,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : -2242.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1031",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Raises user's Attack and Speed.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Raises user's Attack and Speed.\"",
        "SelfLoops" : 0,
        "SUID" : 1031,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : -2242.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1029",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Raises user's Special Defense and next Electric move's power increases.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Raises user's Special Defense and next Electric move's power increases.\"",
        "SelfLoops" : 0,
        "SUID" : 1029,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : -2242.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1027",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Changes user's type according to the location.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Changes user's type according to the location.\"",
        "SelfLoops" : 0,
        "SUID" : 1027,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : -2242.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1025",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Raises user's Special Attack and Special Defense.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Raises user's Special Attack and Special Defense.\"",
        "SelfLoops" : 0,
        "SUID" : 1025,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : -2242.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1023",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Raises user's Attack and Defense.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Raises user's Attack and Defense.\"",
        "SelfLoops" : 0,
        "SUID" : 1023,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : -2242.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1021",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"User performs a move known by its allies at random.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"User performs a move known by its allies at random.\"",
        "SelfLoops" : 0,
        "SUID" : 1021,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : -2242.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1019",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Cures all status problems in your party.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Cures all status problems in your party.\"",
        "SelfLoops" : 0,
        "SUID" : 1019,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : -2142.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1017",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Lowers opponent's Evasiveness.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Lowers opponent's Evasiveness.\"",
        "SelfLoops" : 0,
        "SUID" : 1017,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : -2142.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1015",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Confuses opponent, but sharply raises its Attack.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Confuses opponent, but sharply raises its Attack.\"",
        "SelfLoops" : 0,
        "SUID" : 1015,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : -2142.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1013",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Makes it sunny for 5 turns.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Makes it sunny for 5 turns.\"",
        "SelfLoops" : 0,
        "SUID" : 1013,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : -2142.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1011",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"The opponent's last move loses 2-5 PP.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"The opponent's last move loses 2-5 PP.\"",
        "SelfLoops" : 0,
        "SUID" : 1011,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : -2142.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1009",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Damages opponents switching into battle.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Damages opponents switching into battle.\"",
        "SelfLoops" : 0,
        "SUID" : 1009,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : -2142.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1007",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Opponent cannot escape/switch.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Opponent cannot escape/switch.\"",
        "SelfLoops" : 0,
        "SUID" : 1007,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : -2142.937853107345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1005",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"User performs one of its own moves while sleeping.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"User performs one of its own moves while sleeping.\"",
        "SelfLoops" : 0,
        "SUID" : 1005,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : -2042.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1003",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Permanently copies the opponent's last move.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Permanently copies the opponent's last move.\"",
        "SelfLoops" : 0,
        "SUID" : 1003,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : -2042.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1001",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Creates a sandstorm for 5 turns.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Creates a sandstorm for 5 turns.\"",
        "SelfLoops" : 0,
        "SUID" : 1001,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : -2042.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "999",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"The user's party is protected from status conditions.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"The user's party is protected from status conditions.\"",
        "SelfLoops" : 0,
        "SUID" : 999,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : -2042.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "997",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Makes it rain for 5 turns.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Makes it rain for 5 turns.\"",
        "SelfLoops" : 0,
        "SUID" : 997,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : -2042.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "995",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Copies the opponent's stat changes.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Copies the opponent's stat changes.\"",
        "SelfLoops" : 0,
        "SUID" : 995,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : -2042.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "993",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Any Pokémon in play when this attack is used faints in 3 turns.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Any Pokémon in play when this attack is used faints in 3 turns.\"",
        "SelfLoops" : 0,
        "SUID" : 993,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : -2042.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "991",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"The user's and opponent's HP becomes the average of both.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"The user's and opponent's HP becomes the average of both.\"",
        "SelfLoops" : 0,
        "SUID" : 991,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : -1942.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "989",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"The sleeping opponent loses 25% of its max HP each turn.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"The sleeping opponent loses 25% of its max HP each turn.\"",
        "SelfLoops" : 0,
        "SUID" : 989,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : -1942.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "987",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"User recovers HP. Amount varies with the weather.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"User recovers HP. Amount varies with the weather.\"",
        "SelfLoops" : 0,
        "SUID" : 987,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : -1942.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "985",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"User's next attack is guaranteed to hit.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"User's next attack is guaranteed to hit.\"",
        "SelfLoops" : 0,
        "SUID" : 985,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : -1942.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "983",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Heals the user's party's status conditions.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Heals the user's party's status conditions.\"",
        "SelfLoops" : 0,
        "SUID" : 983,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : -1942.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "981",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Resets opponent's Evasiveness, and allows Normal- and Fighting-type attacks to hit Ghosts.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Resets opponent's Evasiveness, and allows Normal- and Fighting-type attacks to hit Ghosts.\"",
        "SelfLoops" : 0,
        "SUID" : 981,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : -1942.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "979",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Always left with at least 1 HP, but may fail if used consecutively.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Always left with at least 1 HP, but may fail if used consecutively.\"",
        "SelfLoops" : 0,
        "SUID" : 979,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : -1942.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "977",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Forces opponent to keep using its last move for 3 turns.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Forces opponent to keep using its last move for 3 turns.\"",
        "SelfLoops" : 0,
        "SUID" : 977,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : -1842.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "975",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Protects the user, but may fail if used consecutively.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Protects the user, but may fail if used consecutively.\"",
        "SelfLoops" : 0,
        "SUID" : 975,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : -1842.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "973",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"If the user faints, the opponent also faints.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"If the user faints, the opponent also faints.\"",
        "SelfLoops" : 0,
        "SUID" : 973,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : -1842.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "971",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Ghosts lose 50% of max HP and curse the opponent; Non-Ghosts raise Attack, Defense and lower Speed.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Ghosts lose 50% of max HP and curse the opponent; Non-Ghosts raise Attack, Defense and lower Speed.\"",
        "SelfLoops" : 0,
        "SUID" : 971,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : -1842.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "969",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"User changes type to become resistant to opponent's last move.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"User changes type to become resistant to opponent's last move.\"",
        "SelfLoops" : 0,
        "SUID" : 969,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : -1842.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "967",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Sharply lowers opponent's Attack.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Sharply lowers opponent's Attack.\"",
        "SelfLoops" : 0,
        "SUID" : 967,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : -1842.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "965",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"User loses 50% of its max HP, but Attack raises to maximum.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"User loses 50% of its max HP, but Attack raises to maximum.\"",
        "SelfLoops" : 0,
        "SUID" : 965,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : -1842.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "963",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"User switches out and gives stat changes to the incoming Pokémon.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"User switches out and gives stat changes to the incoming Pokémon.\"",
        "SelfLoops" : 0,
        "SUID" : 963,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : -1742.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "961",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"If opponent is the opposite gender, it's less likely to attack.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"If opponent is the opposite gender, it's less likely to attack.\"",
        "SelfLoops" : 0,
        "SUID" : 961,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : -1742.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "959",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"User takes on the form and attacks of the opponent.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"User takes on the form and attacks of the opponent.\"",
        "SelfLoops" : 0,
        "SUID" : 959,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : -1742.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "957",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Badly poisons opponent.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Badly poisons opponent.\"",
        "SelfLoops" : 0,
        "SUID" : 957,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : -1742.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "955",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Allows user to flee wild battles; also warps player to last PokéCenter.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Allows user to flee wild battles; also warps player to last PokéCenter.\"",
        "SelfLoops" : 0,
        "SUID" : 955,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : -1742.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "953",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Sharply raises user's Attack.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Sharply raises user's Attack.\"",
        "SelfLoops" : 0,
        "SUID" : 953,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : -1742.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "951",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Uses HP to creates a decoy that takes hits.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Uses HP to creates a decoy that takes hits.\"",
        "SelfLoops" : 0,
        "SUID" : 951,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : -1742.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "949",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Sharply lowers opponent's Speed.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Sharply lowers opponent's Speed.\"",
        "SelfLoops" : 0,
        "SUID" : 949,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : -1642.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "947",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Doesn't do ANYTHING.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Doesn't do ANYTHING.\"",
        "SelfLoops" : 0,
        "SUID" : 947,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : -1642.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "945",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Sharply lowers opponent's Defense.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Sharply lowers opponent's Defense.\"",
        "SelfLoops" : 0,
        "SUID" : 945,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : -1642.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "943",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"User sleeps for 2 turns, but user is fully healed.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"User sleeps for 2 turns, but user is fully healed.\"",
        "SelfLoops" : 0,
        "SUID" : 943,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : -1642.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "941",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Halves damage from Physical attacks for 5 turns.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Halves damage from Physical attacks for 5 turns.\"",
        "SelfLoops" : 0,
        "SUID" : 941,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : -1642.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "939",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"User recovers half its max HP.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"User recovers half its max HP.\"",
        "SelfLoops" : 0,
        "SUID" : 939,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : -1642.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "937",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Poisons opponent.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Poisons opponent.\"",
        "SelfLoops" : 0,
        "SUID" : 937,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : -1642.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "935",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"User's stats cannot be changed for a period of time.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"User's stats cannot be changed for a period of time.\"",
        "SelfLoops" : 0,
        "SUID" : 935,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : -1542.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "933",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"User performs the opponent's last move.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"User performs the opponent's last move.\"",
        "SelfLoops" : 0,
        "SUID" : 933,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : -1542.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "931",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Sharply raises user's Evasiveness.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Sharply raises user's Evasiveness.\"",
        "SelfLoops" : 0,
        "SUID" : 931,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : -1542.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "929",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Copies the opponent's last move.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Copies the opponent's last move.\"",
        "SelfLoops" : 0,
        "SUID" : 929,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : -1542.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "927",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"User performs almost any move in the game at random.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"User performs almost any move in the game at random.\"",
        "SelfLoops" : 0,
        "SUID" : 927,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : -1542.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "925",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Raises user's Attack.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Raises user's Attack.\"",
        "SelfLoops" : 0,
        "SUID" : 925,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : -1542.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "923",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Halves damage from Special attacks for 5 turns.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Halves damage from Special attacks for 5 turns.\"",
        "SelfLoops" : 0,
        "SUID" : 923,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : -1542.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "921",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Puts opponent to sleep.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Puts opponent to sleep.\"",
        "SelfLoops" : 0,
        "SUID" : 921,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : -1442.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "919",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Raises user's Attack and Special Attack.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Raises user's Attack and Special Attack.\"",
        "SelfLoops" : 0,
        "SUID" : 919,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : -1442.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "917",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Increases critical hit ratio.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Increases critical hit ratio.\"",
        "SelfLoops" : 0,
        "SUID" : 917,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : -1442.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "915",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Raises user's Evasiveness.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Raises user's Evasiveness.\"",
        "SelfLoops" : 0,
        "SUID" : 915,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : -1442.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "913",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Opponent can't use its last attack for a few turns.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Opponent can't use its last attack for a few turns.\"",
        "SelfLoops" : 0,
        "SUID" : 913,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : -1442.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "911",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Raises user's Defense.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Raises user's Defense.\"",
        "SelfLoops" : 0,
        "SUID" : 911,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : -1442.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "909",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Changes user's type to that of its first move.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Changes user's type to that of its first move.\"",
        "SelfLoops" : 0,
        "SUID" : 909,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : -1442.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "907",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Sharply raises user's Special Defense.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Sharply raises user's Special Defense.\"",
        "SelfLoops" : 0,
        "SUID" : 907,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : -1342.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "905",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Sharply raises user's Speed.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Sharply raises user's Speed.\"",
        "SelfLoops" : 0,
        "SUID" : 905,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : -1342.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "903",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Sharply raises user's Defense.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Sharply raises user's Defense.\"",
        "SelfLoops" : 0,
        "SUID" : 903,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : -1342.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "901",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Poisons opponent and lowers its Speed.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Poisons opponent and lowers its Speed.\"",
        "SelfLoops" : 0,
        "SUID" : 901,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : -1342.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "899",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"The user gets teary eyed to make the target lose its combative spirit. This lowers the target's Attack and Sp. Atk stats.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"The user gets teary eyed to make the target lose its combative spirit. This lowers the target's Attack and Sp. Atk stats.\"",
        "SelfLoops" : 0,
        "SUID" : 899,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : -1342.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "897",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"The user restores its HP by the same amount as the target's Attack stat. It also lowers the target's Attack stat.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"The user restores its HP by the same amount as the target's Attack stat. It also lowers the target's Attack stat.\"",
        "SelfLoops" : 0,
        "SUID" : 897,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : -1342.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "895",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"The user shines a spotlight on the target so that only the target will be attacked during the turn.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"The user shines a spotlight on the target so that only the target will be attacked during the turn.\"",
        "SelfLoops" : 0,
        "SUID" : 895,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : -1342.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "893",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"The user exchanges Speed stats with the target.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"The user exchanges Speed stats with the target.\"",
        "SelfLoops" : 0,
        "SUID" : 893,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : -1242.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "891",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"The user regains up to half of its max HP. It restores more HP in a sandstorm.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"The user regains up to half of its max HP. It restores more HP in a sandstorm.\"",
        "SelfLoops" : 0,
        "SUID" : 891,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : -1242.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "889",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"The user heals the target's status condition. If the move succeeds, it also restores the user's own HP.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"The user heals the target's status condition. If the move succeeds, it also restores the user's own HP.\"",
        "SelfLoops" : 0,
        "SUID" : 889,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : -1242.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "887",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Prevents priority moves from being used for 5 turns.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Prevents priority moves from being used for 5 turns.\"",
        "SelfLoops" : 0,
        "SUID" : 887,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : -1242.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "885",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"User's next attack is guaranteed to result in a critical hit.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"User's next attack is guaranteed to result in a critical hit.\"",
        "SelfLoops" : 0,
        "SUID" : 885,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : -1242.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "883",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Allows an ally to use a move instead.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Allows an ally to use a move instead.\"",
        "SelfLoops" : 0,
        "SUID" : 883,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : -1242.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "881",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"The user engages its gears to raise the Attack and Sp. Atk stats of ally Pokémon with the Plus or Minus Ability.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"The user engages its gears to raise the Attack and Sp. Atk stats of ally Pokémon with the Plus or Minus Ability.\"",
        "SelfLoops" : 0,
        "SUID" : 881,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : -1242.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "879",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"The user restores the target's HP by up to half of its max HP. It restores more HP when the terrain is grass.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"The user restores the target's HP by up to half of its max HP. It restores more HP when the terrain is grass.\"",
        "SelfLoops" : 0,
        "SUID" : 879,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : -1142.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "877",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Eevee-exclusive Z-Move. Sharply raises all stats.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Eevee-exclusive Z-Move. Sharply raises all stats.\"",
        "SelfLoops" : 0,
        "SUID" : 877,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : -1142.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "875",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Protects the user and poisons opponent on contact.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Protects the user and poisons opponent on contact.\"",
        "SelfLoops" : 0,
        "SUID" : 875,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : -1142.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "873",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Halves damage from Physical and Special attacks for five turns.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Halves damage from Physical and Special attacks for five turns.\"",
        "SelfLoops" : 0,
        "SUID" : 873,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : -1142.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "871",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Lowers poisoned opponent's Special Attack and Speed.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Lowers poisoned opponent's Special Attack and Speed.\"",
        "SelfLoops" : 0,
        "SUID" : 871,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : -1142.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "869",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Adds Ghost type to opponent.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Adds Ghost type to opponent.\"",
        "SelfLoops" : 0,
        "SUID" : 869,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : -1142.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "867",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Reverses stat changes of opponent.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Reverses stat changes of opponent.\"",
        "SelfLoops" : 0,
        "SUID" : 867,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : -1142.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "865",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Lowers opponent's Speed when switching into battle.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Lowers opponent's Speed when switching into battle.\"",
        "SelfLoops" : 0,
        "SUID" : 865,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : -1042.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "863",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Protects the user and inflicts damage on contact.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Protects the user and inflicts damage on contact.\"",
        "SelfLoops" : 0,
        "SUID" : 863,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : -1042.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "861",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Raises Attack and Special Attack of Grass-types.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Raises Attack and Special Attack of Grass-types.\"",
        "SelfLoops" : 0,
        "SUID" : 861,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : -1042.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "859",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Damages Pokémon using Fire type moves.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Damages Pokémon using Fire type moves.\"",
        "SelfLoops" : 0,
        "SUID" : 859,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : -1042.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "857",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Lowers opponent's Attack. Always hits.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Lowers opponent's Attack. Always hits.\"",
        "SelfLoops" : 0,
        "SUID" : 857,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : -1042.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "855",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Lowers opponent's Attack and Special Attack then switches out.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Lowers opponent's Attack and Special Attack then switches out.\"",
        "SelfLoops" : 0,
        "SUID" : 855,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : -1042.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "853",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Lowers opponent's Attack and Special Attack.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Lowers opponent's Attack and Special Attack.\"",
        "SelfLoops" : 0,
        "SUID" : 853,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : -1042.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "851",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Protects the field from status conditions for 5 turns.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Protects the field from status conditions for 5 turns.\"",
        "SelfLoops" : 0,
        "SUID" : 851,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : -942.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "849",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Protects teammates from damaging moves.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Protects teammates from damaging moves.\"",
        "SelfLoops" : 0,
        "SUID" : 849,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : -942.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "847",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Raises Defense and Sp. Defense of Plus/Minus Pokémon.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Raises Defense and Sp. Defense of Plus/Minus Pokémon.\"",
        "SelfLoops" : 0,
        "SUID" : 847,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : -942.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "845",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Protects the user and lowers opponent's Attack on contact.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Protects the user and lowers opponent's Attack on contact.\"",
        "SelfLoops" : 0,
        "SUID" : 845,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : -942.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "843",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Changes Normal-type moves to Electric-type.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Changes Normal-type moves to Electric-type.\"",
        "SelfLoops" : 0,
        "SUID" : 843,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : -942.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "841",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Makes the user and an ally very happy.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Makes the user and an ally very happy.\"",
        "SelfLoops" : 0,
        "SUID" : 841,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : -942.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "839",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Doubles prize money from trainer battles.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Doubles prize money from trainer battles.\"",
        "SelfLoops" : 0,
        "SUID" : 839,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : -942.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "837",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Restores a little HP of all Pokémon for 5 turns.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Restores a little HP of all Pokémon for 5 turns.\"",
        "SelfLoops" : 0,
        "SUID" : 837,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : -842.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "835",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Charges on first turn, sharply raises user's Sp. Attack, Sp. Defense and Speed on the second.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Charges on first turn, sharply raises user's Sp. Attack, Sp. Defense and Speed on the second.\"",
        "SelfLoops" : 0,
        "SUID" : 835,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : -842.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "833",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Adds Grass type to opponent.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Adds Grass type to opponent.\"",
        "SelfLoops" : 0,
        "SUID" : 833,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : -842.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "831",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Sharply raises Defense of all Grass-type Pokémon on the field.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Sharply raises Defense of all Grass-type Pokémon on the field.\"",
        "SelfLoops" : 0,
        "SUID" : 831,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : -842.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "829",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Prevents fleeing in the next turn.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Prevents fleeing in the next turn.\"",
        "SelfLoops" : 0,
        "SUID" : 829,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : -842.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "827",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Changes the target's move to Electric type.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Changes the target's move to Electric type.\"",
        "SelfLoops" : 0,
        "SUID" : 827,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : -842.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "825",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Prevents all Pokémon from falling asleep for 5 turns.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Prevents all Pokémon from falling asleep for 5 turns.\"",
        "SelfLoops" : 0,
        "SUID" : 825,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : -842.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "823",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Sharply lowers opponent's Special Attack.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Sharply lowers opponent's Special Attack.\"",
        "SelfLoops" : 0,
        "SUID" : 823,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : -742.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "821",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Protects the Pokémon from status moves.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Protects the Pokémon from status moves.\"",
        "SelfLoops" : 0,
        "SUID" : 821,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : -742.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "819",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"The Pokémon congratulates you on your special day. No battle effect.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"The Pokémon congratulates you on your special day. No battle effect.\"",
        "SelfLoops" : 0,
        "SUID" : 819,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : -742.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "817",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Always goes first. Lowers the target's attack.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Always goes first. Lowers the target's attack.\"",
        "SelfLoops" : 0,
        "SUID" : 817,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : -742.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "815",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Added effects appear if preceded by Fire Pledge or succeeded by Grass Pledge.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Added effects appear if preceded by Fire Pledge or succeeded by Grass Pledge.\"",
        "SelfLoops" : 0,
        "SUID" : 815,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : -742.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "813",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"User must switch out after attacking.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"User must switch out after attacking.\"",
        "SelfLoops" : 0,
        "SUID" : 813,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : -742.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "811",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Inflicts double damage if the target is poisoned.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Inflicts double damage if the target is poisoned.\"",
        "SelfLoops" : 0,
        "SUID" : 811,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : -742.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "809",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Type depends on the Drive being held.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Type depends on the Drive being held.\"",
        "SelfLoops" : 0,
        "SUID" : 809,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : -642.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "807",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Hits any Pokémon that shares a type with the user.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Hits any Pokémon that shares a type with the user.\"",
        "SelfLoops" : 0,
        "SUID" : 807,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : -642.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "805",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Power increases when user's stats have been raised.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Power increases when user's stats have been raised.\"",
        "SelfLoops" : 0,
        "SUID" : 805,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : -642.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "803",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Power increases if teammates use it in the same turn.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Power increases if teammates use it in the same turn.\"",
        "SelfLoops" : 0,
        "SUID" : 803,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : -642.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "801",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"May put the target to sleep.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"May put the target to sleep.\"",
        "SelfLoops" : 0,
        "SUID" : 801,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : -642.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "799",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Inflicts damage based on the target's Defense, not Special Defense.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Inflicts damage based on the target's Defense, not Special Defense.\"",
        "SelfLoops" : 0,
        "SUID" : 799,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : -642.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "797",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Burns opponent.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Burns opponent.\"",
        "SelfLoops" : 0,
        "SUID" : 797,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : -642.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "795",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Destroys the target's held berry.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Destroys the target's held berry.\"",
        "SelfLoops" : 0,
        "SUID" : 795,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : -542.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "793",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Charges on first turn, attacks on second. May burn opponent.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Charges on first turn, attacks on second. May burn opponent.\"",
        "SelfLoops" : 0,
        "SUID" : 793,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : -542.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "791",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Inflicts more damage if the target has a status condition.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Inflicts more damage if the target has a status condition.\"",
        "SelfLoops" : 0,
        "SUID" : 791,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : -542.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "789",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Added effects appear if preceded by Water Pledge or succeeded by Fire Pledge.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Added effects appear if preceded by Water Pledge or succeeded by Fire Pledge.\"",
        "SelfLoops" : 0,
        "SUID" : 789,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : -542.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "787",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Power increases if Fusion Bolt is used in the same turn.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Power increases if Fusion Bolt is used in the same turn.\"",
        "SelfLoops" : 0,
        "SUID" : 787,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : -542.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "785",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"May also injure nearby Pokémon.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"May also injure nearby Pokémon.\"",
        "SelfLoops" : 0,
        "SUID" : 785,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : -542.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "783",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Added effects appear if combined with Grass Pledge or Water Pledge.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Added effects appear if combined with Grass Pledge or Water Pledge.\"",
        "SelfLoops" : 0,
        "SUID" : 783,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : -542.9378531073448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "781",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Inflicts damage equal to the user's remaining HP. User faints.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Inflicts damage equal to the user's remaining HP. User faints.\"",
        "SelfLoops" : 0,
        "SUID" : 781,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : -442.93785310734484
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "779",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"The faster the user, the stronger the attack.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"The faster the user, the stronger the attack.\"",
        "SelfLoops" : 0,
        "SUID" : 779,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : -442.93785310734484
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "777",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Removes all of the target's stat changes.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Removes all of the target's stat changes.\"",
        "SelfLoops" : 0,
        "SUID" : 777,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : -442.93785310734484
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "775",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Sharply lowers opponent's Special Defense.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Sharply lowers opponent's Special Defense.\"",
        "SelfLoops" : 0,
        "SUID" : 775,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : -442.93785310734484
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "773",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Strikes before a target's move.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Strikes before a target's move.\"",
        "SelfLoops" : 0,
        "SUID" : 773,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : -442.93785310734484
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "771",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Changes type when the user has Terastallized.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Changes type when the user has Terastallized.\"",
        "SelfLoops" : 0,
        "SUID" : 771,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : -442.93785310734484
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "769",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Guaranteed to hit twice in a row.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Guaranteed to hit twice in a row.\"",
        "SelfLoops" : 0,
        "SUID" : 769,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : -442.93785310734484
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "767",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Lowers opponent's Speed each turn for 3 turns.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Lowers opponent's Speed each turn for 3 turns.\"",
        "SelfLoops" : 0,
        "SUID" : 767,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : -342.93785310734484
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "765",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Halves the opponent's HP.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Halves the opponent's HP.\"",
        "SelfLoops" : 0,
        "SUID" : 765,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : -342.93785310734484
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "763",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Deals damage and prevents target from healing.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Deals damage and prevents target from healing.\"",
        "SelfLoops" : 0,
        "SUID" : 763,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : -342.93785310734484
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "761",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Deals damage, restores HP, may burn opponent.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Deals damage, restores HP, may burn opponent.\"",
        "SelfLoops" : 0,
        "SUID" : 761,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : -342.93785310734484
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "759",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Lowers user's Special Attack. Money is earned after the battle.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Lowers user's Special Attack. Money is earned after the battle.\"",
        "SelfLoops" : 0,
        "SUID" : 759,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : -342.93785310734484
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "757",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Harshly lowers target’s Special Defense.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Harshly lowers target’s Special Defense.\"",
        "SelfLoops" : 0,
        "SUID" : 757,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : -342.93785310734484
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "755",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Power increases in harsh sunlight.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Power increases in harsh sunlight.\"",
        "SelfLoops" : 0,
        "SUID" : 755,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : -342.93785310734484
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "753",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"May deal double damage.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"May deal double damage.\"",
        "SelfLoops" : 0,
        "SUID" : 753,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : -242.93785310734484
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "751",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"May paralyze target.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"May paralyze target.\"",
        "SelfLoops" : 0,
        "SUID" : 751,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : -242.93785310734484
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "749",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Deals damage and traps opponent, damaging them for 4-5 turns.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Deals damage and traps opponent, damaging them for 4-5 turns.\"",
        "SelfLoops" : 0,
        "SUID" : 749,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : -242.93785310734484
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "747",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Type and power change depending on the Terrain in effect.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Type and power change depending on the Terrain in effect.\"",
        "SelfLoops" : 0,
        "SUID" : 747,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : -242.93785310734484
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "745",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"User loses 50% of its HP.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"User loses 50% of its HP.\"",
        "SelfLoops" : 0,
        "SUID" : 745,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : -242.93785310734484
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "743",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Boosts user's stats in Incarnate Forme, or lowers opponent's stats in Therian Forme.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Boosts user's stats in Incarnate Forme, or lowers opponent's stats in Therian Forme.\"",
        "SelfLoops" : 0,
        "SUID" : 743,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : -242.93785310734484
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "741",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Ignores moves and abilities that draw in moves. High critical hit ratio.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Ignores moves and abilities that draw in moves. High critical hit ratio.\"",
        "SelfLoops" : 0,
        "SUID" : 741,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : -242.93785310734484
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "739",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"May poison opponent. Inflicts either Special or Physical damage, whichever is better.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"May poison opponent. Inflicts either Special or Physical damage, whichever is better.\"",
        "SelfLoops" : 0,
        "SUID" : 739,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : -142.93785310734484
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "737",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"May burn the target.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"May burn the target.\"",
        "SelfLoops" : 0,
        "SUID" : 737,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : -142.93785310734484
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "735",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"May burn target.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"May burn target.\"",
        "SelfLoops" : 0,
        "SUID" : 735,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : -142.93785310734484
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "733",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Power doubles on Electric Terrain.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Power doubles on Electric Terrain.\"",
        "SelfLoops" : 0,
        "SUID" : 733,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : -142.93785310734484
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "731",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Raises user's Special Attack.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Raises user's Special Attack.\"",
        "SelfLoops" : 0,
        "SUID" : 731,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : -142.93785310734484
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "729",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Power increases on Misty Terrain.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Power increases on Misty Terrain.\"",
        "SelfLoops" : 0,
        "SUID" : 729,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : -142.93785310734484
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "727",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"User gathers space power and boosts its Sp. Atk stat, then attacks the target on the next turn.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"User gathers space power and boosts its Sp. Atk stat, then attacks the target on the next turn.\"",
        "SelfLoops" : 0,
        "SUID" : 727,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : -142.93785310734484
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "725",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Inflicts double damage if the target has a status condition.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Inflicts double damage if the target has a status condition.\"",
        "SelfLoops" : 0,
        "SUID" : 725,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : -42.937853107344836
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "723",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Increases power and hits all opponents on Psychic Terrain.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Increases power and hits all opponents on Psychic Terrain.\"",
        "SelfLoops" : 0,
        "SUID" : 723,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : -42.937853107344836
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "721",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"User can't move on the next turn.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"User can't move on the next turn.\"",
        "SelfLoops" : 0,
        "SUID" : 721,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : -42.937853107344836
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "719",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"High critical hit ratio. Raises user's Speed.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"High critical hit ratio. Raises user's Speed.\"",
        "SelfLoops" : 0,
        "SUID" : 719,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : -42.937853107344836
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "717",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Deals damage and reduces opponent's PP.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Deals damage and reduces opponent's PP.\"",
        "SelfLoops" : 0,
        "SUID" : 717,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : -42.937853107344836
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "715",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Damage doubles if opponent is Dynamaxed.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Damage doubles if opponent is Dynamaxed.\"",
        "SelfLoops" : 0,
        "SUID" : 715,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : -42.937853107344836
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "713",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"The higher the user's HP, the higher the power.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"The higher the user's HP, the higher the power.\"",
        "SelfLoops" : 0,
        "SUID" : 713,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : -42.937853107344836
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "711",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Hits all opponents, and burns any that have had their stats boosted.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Hits all opponents, and burns any that have had their stats boosted.\"",
        "SelfLoops" : 0,
        "SUID" : 711,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : 57.062146892655164
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "709",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"The user attacks by sending a frightful amount of small ghosts at opposing Pokémon.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"The user attacks by sending a frightful amount of small ghosts at opposing Pokémon.\"",
        "SelfLoops" : 0,
        "SUID" : 709,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : 57.062146892655164
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "707",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Lowers target's Special Defense.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Lowers target's Special Defense.\"",
        "SelfLoops" : 0,
        "SUID" : 707,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : 57.062146892655164
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "705",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"The higher the opponent's HP, the higher the damage.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"The higher the opponent's HP, the higher the damage.\"",
        "SelfLoops" : 0,
        "SUID" : 705,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : 57.062146892655164
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "703",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"The lower the PP, the higher the power.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"The lower the PP, the higher the power.\"",
        "SelfLoops" : 0,
        "SUID" : 703,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : 57.062146892655164
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "701",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Type depends on the Arceus Plate being held.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Type depends on the Arceus Plate being held.\"",
        "SelfLoops" : 0,
        "SUID" : 701,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : 57.062146892655164
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "699",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"May raise user's Special Attack.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"May raise user's Special Attack.\"",
        "SelfLoops" : 0,
        "SUID" : 699,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : 57.062146892655164
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "697",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Power doubles if opponent's HP is less than 50%.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Power doubles if opponent's HP is less than 50%.\"",
        "SelfLoops" : 0,
        "SUID" : 697,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : 157.06214689265516
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "695",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Move's power and type changes with the weather.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Move's power and type changes with the weather.\"",
        "SelfLoops" : 0,
        "SUID" : 695,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : 157.06214689265516
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "693",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"The higher the user's HP, the higher the damage caused.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"The higher the user's HP, the higher the damage caused.\"",
        "SelfLoops" : 0,
        "SUID" : 693,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : 157.06214689265516
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "691",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"User attacks for 3 turns and prevents sleep.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"User attacks for 3 turns and prevents sleep.\"",
        "SelfLoops" : 0,
        "SUID" : 691,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : 157.06214689265516
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "689",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Power depends on how many times the user performed Stockpile.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Power depends on how many times the user performed Stockpile.\"",
        "SelfLoops" : 0,
        "SUID" : 689,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : 157.06214689265516
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "687",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"May raise all stats of user at once.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"May raise all stats of user at once.\"",
        "SelfLoops" : 0,
        "SUID" : 687,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : 157.06214689265516
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "685",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Stronger when the user's HP is higher.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Stronger when the user's HP is higher.\"",
        "SelfLoops" : 0,
        "SUID" : 685,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : 157.06214689265516
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "683",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"May cause flinching. Hits Pokémon using Fly/Bounce with double power.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"May cause flinching. Hits Pokémon using Fly/Bounce with double power.\"",
        "SelfLoops" : 0,
        "SUID" : 683,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : 257.06214689265516
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "681",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Can only be used if asleep. May cause flinching.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Can only be used if asleep. May cause flinching.\"",
        "SelfLoops" : 0,
        "SUID" : 681,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : 257.06214689265516
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "679",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"May lower opponent's Accuracy.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"May lower opponent's Accuracy.\"",
        "SelfLoops" : 0,
        "SUID" : 679,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : 257.06214689265516
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "677",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Lowers opponent's Accuracy.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Lowers opponent's Accuracy.\"",
        "SelfLoops" : 0,
        "SUID" : 677,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : 257.06214689265516
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "675",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"When hit by a Special Attack, user strikes back with 2x power.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"When hit by a Special Attack, user strikes back with 2x power.\"",
        "SelfLoops" : 0,
        "SUID" : 675,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : 257.06214689265516
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "673",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Type and power depends on user's IVs.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Type and power depends on user's IVs.\"",
        "SelfLoops" : 0,
        "SUID" : 673,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : 257.06214689265516
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "671",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Damage occurs 2 turns later.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Damage occurs 2 turns later.\"",
        "SelfLoops" : 0,
        "SUID" : 671,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : 257.06214689265516
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "669",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"May raise all user's stats at once.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"May raise all user's stats at once.\"",
        "SelfLoops" : 0,
        "SUID" : 669,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : 357.06214689265516
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "667",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"May paralyze, burn or freeze opponent.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"May paralyze, burn or freeze opponent.\"",
        "SelfLoops" : 0,
        "SUID" : 667,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : 357.06214689265516
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "665",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Always inflicts 20 HP.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Always inflicts 20 HP.\"",
        "SelfLoops" : 0,
        "SUID" : 665,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : 357.06214689265516
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "663",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Charges on first turn, attacks on second. High critical hit ratio.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Charges on first turn, attacks on second. High critical hit ratio.\"",
        "SelfLoops" : 0,
        "SUID" : 663,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : 357.06214689265516
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "661",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Inflicts damage 50-150% of user's level.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Inflicts damage 50-150% of user's level.\"",
        "SelfLoops" : 0,
        "SUID" : 661,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : 357.06214689265516
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "659",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Hits Pokémon using Fly/Bounce/Sky Drop with double power.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Hits Pokémon using Fly/Bounce/Sky Drop with double power.\"",
        "SelfLoops" : 0,
        "SUID" : 659,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : 357.06214689265516
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "657",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"User recovers half the HP inflicted on a sleeping opponent.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"User recovers half the HP inflicted on a sleeping opponent.\"",
        "SelfLoops" : 0,
        "SUID" : 657,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : 357.06214689265516
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "655",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Always inflicts 40 HP.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Always inflicts 40 HP.\"",
        "SelfLoops" : 0,
        "SUID" : 655,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : 457.06214689265516
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "653",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"May lower opponent's Speed.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"May lower opponent's Speed.\"",
        "SelfLoops" : 0,
        "SUID" : 653,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : 457.06214689265516
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "651",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"May lower opponent's Special Defense.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"May lower opponent's Special Defense.\"",
        "SelfLoops" : 0,
        "SUID" : 651,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : 457.06214689265516
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "649",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Alolan Raichu-exclusive Electric type Z-Move.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Alolan Raichu-exclusive Electric type Z-Move.\"",
        "SelfLoops" : 0,
        "SUID" : 649,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : 457.06214689265516
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "647",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Cures all status problems in the party Pokémon.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Cures all status problems in the party Pokémon.\"",
        "SelfLoops" : 0,
        "SUID" : 647,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : 457.06214689265516
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "645",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Heals the burns of its target.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Heals the burns of its target.\"",
        "SelfLoops" : 0,
        "SUID" : 645,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : 457.06214689265516
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "643",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Deals more damage to opponent if hit by a Physical move.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Deals more damage to opponent if hit by a Physical move.\"",
        "SelfLoops" : 0,
        "SUID" : 643,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : 457.06214689265516
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "641",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Type changes based on Oricorio's form.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Type changes based on Oricorio's form.\"",
        "SelfLoops" : 0,
        "SUID" : 641,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : 557.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "639",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"The user shoots powerful lasers using the power of a prism. The user can't move on the next turn.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"The user shoots powerful lasers using the power of a prism. The user can't move on the next turn.\"",
        "SelfLoops" : 0,
        "SUID" : 639,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : 557.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "637",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Deals damage to opponent or restores HP of teammate.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Deals damage to opponent or restores HP of teammate.\"",
        "SelfLoops" : 0,
        "SUID" : 637,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : 557.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "635",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Uses Attack or Special Attack stat, whichever is higher.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Uses Attack or Special Attack stat, whichever is higher.\"",
        "SelfLoops" : 0,
        "SUID" : 635,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : 557.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "633",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Primarina-exclusive Z-Move.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Primarina-exclusive Z-Move.\"",
        "SelfLoops" : 0,
        "SUID" : 633,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : 557.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "631",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Halves the foe's HP.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Halves the foe's HP.\"",
        "SelfLoops" : 0,
        "SUID" : 631,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : 557.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "629",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Lunala-exclusive Z-Move.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Lunala-exclusive Z-Move.\"",
        "SelfLoops" : 0,
        "SUID" : 629,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : 557.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "627",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Ultra Necrozma-exclusive Z-Move. Ignores target's ability; uses highest Attack stat.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Ultra Necrozma-exclusive Z-Move. Ignores target's ability; uses highest Attack stat.\"",
        "SelfLoops" : 0,
        "SUID" : 627,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : 657.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "625",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Tapu-exclusive Z-move. Cuts opponent's HP by 75%.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Tapu-exclusive Z-move. Cuts opponent's HP by 75%.\"",
        "SelfLoops" : 0,
        "SUID" : 625,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : 657.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "623",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Reduces damage from Special attacks.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Reduces damage from Special attacks.\"",
        "SelfLoops" : 0,
        "SUID" : 623,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : 657.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "621",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Mew-exclusive Z-Move.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Mew-exclusive Z-Move.\"",
        "SelfLoops" : 0,
        "SUID" : 621,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : 657.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "619",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Resets all stat changes.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Resets all stat changes.\"",
        "SelfLoops" : 0,
        "SUID" : 619,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : 657.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "617",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Sharply lowers user's Special Attack.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Sharply lowers user's Special Attack.\"",
        "SelfLoops" : 0,
        "SUID" : 617,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : 657.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "615",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Suppresses the target's ability if the target has already moved.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Suppresses the target's ability if the target has already moved.\"",
        "SelfLoops" : 0,
        "SUID" : 615,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : 657.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "613",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Kommo-o exclusive Z-Move.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Kommo-o exclusive Z-Move.\"",
        "SelfLoops" : 0,
        "SUID" : 613,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : 757.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "611",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Paralyzes the opponent.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Paralyzes the opponent.\"",
        "SelfLoops" : 0,
        "SUID" : 611,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : 757.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "609",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"To inflict massive damage, the user burns itself out. After using this move, the user will no longer be Fire type.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"To inflict massive damage, the user burns itself out. After using this move, the user will no longer be Fire type.\"",
        "SelfLoops" : 0,
        "SUID" : 609,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : 757.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "607",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Reduces damage from Physical attacks.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Reduces damage from Physical attacks.\"",
        "SelfLoops" : 0,
        "SUID" : 607,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : 757.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "605",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Pikachu-exclusive Z-Move. High critical hit ratio.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Pikachu-exclusive Z-Move. High critical hit ratio.\"",
        "SelfLoops" : 0,
        "SUID" : 605,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : 757.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "603",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"User recovers most of the HP inflicted on opponent.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"User recovers most of the HP inflicted on opponent.\"",
        "SelfLoops" : 0,
        "SUID" : 603,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : 757.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "601",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"May lower opponent's Special Attack.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"May lower opponent's Special Attack.\"",
        "SelfLoops" : 0,
        "SUID" : 601,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : 757.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "599",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"May freeze opponent. Super-effective against Water types.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"May freeze opponent. Super-effective against Water types.\"",
        "SelfLoops" : 0,
        "SUID" : 599,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : 857.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "597",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"User recovers most the HP inflicted on opponent.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"User recovers most the HP inflicted on opponent.\"",
        "SelfLoops" : 0,
        "SUID" : 597,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : 857.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "595",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Lowers user's Defense, Special Defense and Speed.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Lowers user's Defense, Special Defense and Speed.\"",
        "SelfLoops" : 0,
        "SUID" : 595,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : 857.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "593",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Takes opponent into the air on first turn, drops them on second turn.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Takes opponent into the air on first turn, drops them on second turn.\"",
        "SelfLoops" : 0,
        "SUID" : 593,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : 857.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "591",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Inflicts double damage if a teammate fainted on the last turn.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Inflicts double damage if a teammate fainted on the last turn.\"",
        "SelfLoops" : 0,
        "SUID" : 591,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : 857.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "589",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"The heavier the user, the stronger the attack.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"The heavier the user, the stronger the attack.\"",
        "SelfLoops" : 0,
        "SUID" : 589,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : 857.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "587",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Power increases if Fusion Flare is used in the same turn.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Power increases if Fusion Flare is used in the same turn.\"",
        "SelfLoops" : 0,
        "SUID" : 587,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : 857.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "585",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Charges on first turn, attacks on second. May paralyze opponent.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Charges on first turn, attacks on second. May paralyze opponent.\"",
        "SelfLoops" : 0,
        "SUID" : 585,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : 957.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "583",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Uses the opponent's Attack stat.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Uses the opponent's Attack stat.\"",
        "SelfLoops" : 0,
        "SUID" : 583,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : 957.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "581",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"In battles, the opponent switches. In the wild, the Pokémon runs.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"In battles, the opponent switches. In the wild, the Pokémon runs.\"",
        "SelfLoops" : 0,
        "SUID" : 581,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : 957.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "579",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Stronger when the user does not have a held item.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Stronger when the user does not have a held item.\"",
        "SelfLoops" : 0,
        "SUID" : 579,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : 957.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "577",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"May put opponent to sleep.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"May put opponent to sleep.\"",
        "SelfLoops" : 0,
        "SUID" : 577,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : 957.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "575",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Strikes before a target's priority move.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Strikes before a target's priority move.\"",
        "SelfLoops" : 0,
        "SUID" : 575,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : 957.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "573",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Hits 3 times in a row.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Hits 3 times in a row.\"",
        "SelfLoops" : 0,
        "SUID" : 573,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : 957.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "571",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Harshly lowers user’s Speed.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Harshly lowers user’s Speed.\"",
        "SelfLoops" : 0,
        "SUID" : 571,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : 1057.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "569",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Deals damage each turn; Steel and Water types are more affected.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Deals damage each turn; Steel and Water types are more affected.\"",
        "SelfLoops" : 0,
        "SUID" : 569,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : 1057.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "567",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Type depends on the user’s form. Breaks through Reflect and Light Screen barriers.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Type depends on the user’s form. Breaks through Reflect and Light Screen barriers.\"",
        "SelfLoops" : 0,
        "SUID" : 567,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : 1057.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "565",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"The more times the user has been hit by attacks, the greater the move's power.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"The more times the user has been hit by attacks, the greater the move's power.\"",
        "SelfLoops" : 0,
        "SUID" : 565,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : 1057.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "563",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Power increases on Electric Terrain.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Power increases on Electric Terrain.\"",
        "SelfLoops" : 0,
        "SUID" : 563,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : 1057.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "561",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Hits 1-10 times in a row.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Hits 1-10 times in a row.\"",
        "SelfLoops" : 0,
        "SUID" : 561,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : 1057.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "559",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Boosts Attack/Defense/Speed depending on ally Tatsugiri.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Boosts Attack/Defense/Speed depending on ally Tatsugiri.\"",
        "SelfLoops" : 0,
        "SUID" : 559,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : 1057.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "557",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Removes entry hazards and trap move effects, and poisons opposing Pokémon.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Removes entry hazards and trap move effects, and poisons opposing Pokémon.\"",
        "SelfLoops" : 0,
        "SUID" : 557,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : 1157.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "555",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"May confuse the opponent.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"May confuse the opponent.\"",
        "SelfLoops" : 0,
        "SUID" : 555,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : 1157.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "553",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Damages increases the more party Pokémon have been defeated.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Damages increases the more party Pokémon have been defeated.\"",
        "SelfLoops" : 0,
        "SUID" : 553,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : 1157.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "551",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Always hits.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Always hits.\"",
        "SelfLoops" : 0,
        "SUID" : 551,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : 1157.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "549",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Always goes first.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Always goes first.\"",
        "SelfLoops" : 0,
        "SUID" : 549,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : 1157.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "547",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"High critical hit ratio. Type changes based on form.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"High critical hit ratio. Type changes based on form.\"",
        "SelfLoops" : 0,
        "SUID" : 547,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : 1157.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "545",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Removes effects of Terrain.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Removes effects of Terrain.\"",
        "SelfLoops" : 0,
        "SUID" : 545,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : 1157.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "543",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Can strike through Protect/Detect.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Can strike through Protect/Detect.\"",
        "SelfLoops" : 0,
        "SUID" : 543,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : 1257.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "541",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Attacks from opposing Pokémon during the next turn cannot miss and will inflict double damage.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Attacks from opposing Pokémon during the next turn cannot miss and will inflict double damage.\"",
        "SelfLoops" : 0,
        "SUID" : 541,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : 1257.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "539",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Cannot be used twice in a row.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Cannot be used twice in a row.\"",
        "SelfLoops" : 0,
        "SUID" : 539,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : 1257.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "537",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Never misses; always results in a critical hit.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Never misses; always results in a critical hit.\"",
        "SelfLoops" : 0,
        "SUID" : 537,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : 1257.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "535",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"After using this move, the user will no longer be Electric type.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"After using this move, the user will no longer be Electric type.\"",
        "SelfLoops" : 0,
        "SUID" : 535,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : 1257.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "533",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Deals more damage to the opponent that last inflicted damage on it.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Deals more damage to the opponent that last inflicted damage on it.\"",
        "SelfLoops" : 0,
        "SUID" : 533,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : 1257.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "531",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"May paralyze the opponent.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"May paralyze the opponent.\"",
        "SelfLoops" : 0,
        "SUID" : 531,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : 1257.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "529",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Boosted even more if it's super-effective.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Boosted even more if it's super-effective.\"",
        "SelfLoops" : 0,
        "SUID" : 529,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : 1357.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "527",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"May burn the opponent.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"May burn the opponent.\"",
        "SelfLoops" : 0,
        "SUID" : 527,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : 1357.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "525",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"May confuse opponent. If it misses, the user loses HP.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"May confuse opponent. If it misses, the user loses HP.\"",
        "SelfLoops" : 0,
        "SUID" : 525,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : 1357.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "523",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Raises user's Speed.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Raises user's Speed.\"",
        "SelfLoops" : 0,
        "SUID" : 523,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : 1357.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "521",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Attacks thrice with more power each time.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Attacks thrice with more power each time.\"",
        "SelfLoops" : 0,
        "SUID" : 521,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : 1357.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "519",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"High critical hit ratio. May lower opponent's Defense or cause them to flinch.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"High critical hit ratio. May lower opponent's Defense or cause them to flinch.\"",
        "SelfLoops" : 0,
        "SUID" : 519,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : 1357.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "517",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Lowers opponent's Defense.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Lowers opponent's Defense.\"",
        "SelfLoops" : 0,
        "SUID" : 517,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : 1357.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "515",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Always results in a critical hit and ignores stat changes.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Always results in a critical hit and ignores stat changes.\"",
        "SelfLoops" : 0,
        "SUID" : 515,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : 1457.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "513",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Sets up Stealth Rock.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Sets up Stealth Rock.\"",
        "SelfLoops" : 0,
        "SUID" : 513,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : 1457.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "511",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Fails if no Terrain in effect.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Fails if no Terrain in effect.\"",
        "SelfLoops" : 0,
        "SUID" : 511,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : 1457.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "509",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Lowers opponent's Special Attack.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Lowers opponent's Special Attack.\"",
        "SelfLoops" : 0,
        "SUID" : 509,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : 1457.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "507",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Lowers opponent's Sp. Attack.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Lowers opponent's Sp. Attack.\"",
        "SelfLoops" : 0,
        "SUID" : 507,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : 1457.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "505",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Hits 2-5 times in one turn. Boosts user's Speed but lowers its Defense.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Hits 2-5 times in one turn. Boosts user's Speed but lowers its Defense.\"",
        "SelfLoops" : 0,
        "SUID" : 505,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : 1457.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "503",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Raises user's Defense and Special Defense.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Raises user's Defense and Special Defense.\"",
        "SelfLoops" : 0,
        "SUID" : 503,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : 1457.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "501",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Fails if the target doesn’t have an item.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Fails if the target doesn’t have an item.\"",
        "SelfLoops" : 0,
        "SUID" : 501,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : 1557.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "499",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Double power if stats were lowered during the turn.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Double power if stats were lowered during the turn.\"",
        "SelfLoops" : 0,
        "SUID" : 499,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : 1557.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "497",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Prevents user and opponent from switching out.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Prevents user and opponent from switching out.\"",
        "SelfLoops" : 0,
        "SUID" : 497,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : 1557.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "495",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Lowers user's Defense.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Lowers user's Defense.\"",
        "SelfLoops" : 0,
        "SUID" : 495,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : 1557.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "493",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Lowers the opponent's Defense stat.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Lowers the opponent's Defense stat.\"",
        "SelfLoops" : 0,
        "SUID" : 493,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : 1557.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "491",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"High priority during Grassy Terrain.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"High priority during Grassy Terrain.\"",
        "SelfLoops" : 0,
        "SUID" : 491,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : 1557.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "489",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"The user attacks by hurling a blizzard-cloaked icicle lance at opposing Pokémon.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"The user attacks by hurling a blizzard-cloaked icicle lance at opposing Pokémon.\"",
        "SelfLoops" : 0,
        "SUID" : 489,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : 1557.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "487",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"After making its attack, the user rushes back to switch places with a party Pokémon in waiting.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"After making its attack, the user rushes back to switch places with a party Pokémon in waiting.\"",
        "SelfLoops" : 0,
        "SUID" : 487,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : 1657.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "485",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"The user slams the target with its wings. The target is hit twice in a row.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"The user slams the target with its wings. The target is hit twice in a row.\"",
        "SelfLoops" : 0,
        "SUID" : 485,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : 1657.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "483",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"User attacks twice.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"User attacks twice.\"",
        "SelfLoops" : 0,
        "SUID" : 483,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : 1657.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "481",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"May poison, paralyze or put the opponent to sleep.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"May poison, paralyze or put the opponent to sleep.\"",
        "SelfLoops" : 0,
        "SUID" : 481,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : 1657.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "479",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Sets up Spikes.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Sets up Spikes.\"",
        "SelfLoops" : 0,
        "SUID" : 479,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : 1657.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "477",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Hits multiple opponents and lowers their attack.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Hits multiple opponents and lowers their attack.\"",
        "SelfLoops" : 0,
        "SUID" : 477,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : 1657.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "475",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"If the user attacks before the target, the power of this move is doubled.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"If the user attacks before the target, the power of this move is doubled.\"",
        "SelfLoops" : 0,
        "SUID" : 475,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : 1657.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "473",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"The higher the user's Defense, the stronger the attack.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"The higher the user's Defense, the stronger the attack.\"",
        "SelfLoops" : 0,
        "SUID" : 473,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : 1757.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "471",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Damage doubles if target is Dynamaxed.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Damage doubles if target is Dynamaxed.\"",
        "SelfLoops" : 0,
        "SUID" : 471,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : 1757.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "469",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"May poison opponent; inflicts double damage if the target is already poisoned.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"May poison opponent; inflicts double damage if the target is already poisoned.\"",
        "SelfLoops" : 0,
        "SUID" : 469,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : 1757.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "467",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Changes type based on Morpeko's Mode.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Changes type based on Morpeko's Mode.\"",
        "SelfLoops" : 0,
        "SUID" : 467,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : 1757.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "465",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Power doubles if opponent is asleep, but wakes it up.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Power doubles if opponent is asleep, but wakes it up.\"",
        "SelfLoops" : 0,
        "SUID" : 465,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : 1757.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "463",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"User switches out immediately after attacking.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"User switches out immediately after attacking.\"",
        "SelfLoops" : 0,
        "SUID" : 463,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : 1757.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "461",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"May cause flinching and/or paralyze opponent.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"May cause flinching and/or paralyze opponent.\"",
        "SelfLoops" : 0,
        "SUID" : 461,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : 1757.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "459",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"User attacks first, but only works if opponent is readying an attack.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"User attacks first, but only works if opponent is readying an attack.\"",
        "SelfLoops" : 0,
        "SUID" : 459,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : 1857.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "457",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Power increases when opponent's stats have been raised.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Power increases when opponent's stats have been raised.\"",
        "SelfLoops" : 0,
        "SUID" : 457,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : 1857.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "455",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"If the opponent is holding a berry, its effect is stolen by user.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"If the opponent is holding a berry, its effect is stolen by user.\"",
        "SelfLoops" : 0,
        "SUID" : 455,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : 1857.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "453",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Power doubles if the user was attacked first.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Power doubles if the user was attacked first.\"",
        "SelfLoops" : 0,
        "SUID" : 453,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : 1857.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "451",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Power and type depend on the user's held berry.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Power and type depend on the user's held berry.\"",
        "SelfLoops" : 0,
        "SUID" : 451,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : 1857.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "449",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Deals damage equal to 1.5x opponent's attack.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Deals damage equal to 1.5x opponent's attack.\"",
        "SelfLoops" : 0,
        "SUID" : 449,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : 1857.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "447",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Can only be used after all other moves are used.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Can only be used after all other moves are used.\"",
        "SelfLoops" : 0,
        "SUID" : 447,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : 1857.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "445",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"May cause flinching and/or freeze opponent.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"May cause flinching and/or freeze opponent.\"",
        "SelfLoops" : 0,
        "SUID" : 445,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : 1957.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "443",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Lowers user's Speed.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Lowers user's Speed.\"",
        "SelfLoops" : 0,
        "SUID" : 443,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : 1957.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "441",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"The slower the user, the stronger the attack.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"The slower the user, the stronger the attack.\"",
        "SelfLoops" : 0,
        "SUID" : 441,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : 1957.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "439",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"May poison opponent.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"May poison opponent.\"",
        "SelfLoops" : 0,
        "SUID" : 439,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : 1957.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "437",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"User must recharge next turn.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"User must recharge next turn.\"",
        "SelfLoops" : 0,
        "SUID" : 437,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : 1957.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "435",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Power depends on held item.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Power depends on held item.\"",
        "SelfLoops" : 0,
        "SUID" : 435,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : 1957.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "433",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"User receives recoil damage. May burn opponent.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"User receives recoil damage. May burn opponent.\"",
        "SelfLoops" : 0,
        "SUID" : 433,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : 1957.0621468926552
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "431",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"May cause flinching and/or burn opponent.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"May cause flinching and/or burn opponent.\"",
        "SelfLoops" : 0,
        "SUID" : 431,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : 2057.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "429",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Only hits if opponent uses Protect or Detect in the same turn.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Only hits if opponent uses Protect or Detect in the same turn.\"",
        "SelfLoops" : 0,
        "SUID" : 429,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : 2057.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "427",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"More powerful when opponent has higher HP.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"More powerful when opponent has higher HP.\"",
        "SelfLoops" : 0,
        "SUID" : 427,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : 2057.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "425",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Receives the effect from the opponent's held berry.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Receives the effect from the opponent's held berry.\"",
        "SelfLoops" : 0,
        "SUID" : 425,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : 2057.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "423",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Power doubles if user took damage first.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Power doubles if user took damage first.\"",
        "SelfLoops" : 0,
        "SUID" : 423,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : 2057.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "421",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Power doubles if opponent already took damage in the same turn.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Power doubles if opponent already took damage in the same turn.\"",
        "SelfLoops" : 0,
        "SUID" : 421,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : 2057.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "419",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"User receives recoil damage. May paralyze opponent.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"User receives recoil damage. May paralyze opponent.\"",
        "SelfLoops" : 0,
        "SUID" : 419,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : 2057.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "417",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Lowers user's Attack and Defense.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Lowers user's Attack and Defense.\"",
        "SelfLoops" : 0,
        "SUID" : 417,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : 2157.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "415",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Power doubles if opponent is paralyzed, but cures it.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Power doubles if opponent is paralyzed, but cures it.\"",
        "SelfLoops" : 0,
        "SUID" : 415,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : 2157.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "413",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Hits the opponent, even during Fly.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Hits the opponent, even during Fly.\"",
        "SelfLoops" : 0,
        "SUID" : 413,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : 2157.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "411",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Effects of the attack vary with the location.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Effects of the attack vary with the location.\"",
        "SelfLoops" : 0,
        "SUID" : 411,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : 2157.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "409",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Lowers opponent's Speed.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Lowers opponent's Speed.\"",
        "SelfLoops" : 0,
        "SUID" : 409,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : 2157.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "407",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Power increases if user was hit first.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Power increases if user was hit first.\"",
        "SelfLoops" : 0,
        "SUID" : 407,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : 2157.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "405",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"High critical hit ratio. May poison opponent.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"High critical hit ratio. May poison opponent.\"",
        "SelfLoops" : 0,
        "SUID" : 405,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : 2157.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "403",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"May badly poison opponent.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"May badly poison opponent.\"",
        "SelfLoops" : 0,
        "SUID" : 403,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : 2257.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "401",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Removes opponent's held item for the rest of the battle.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Removes opponent's held item for the rest of the battle.\"",
        "SelfLoops" : 0,
        "SUID" : 401,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : 2257.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "399",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"If the user is hit before attacking, it flinches instead.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"If the user is hit before attacking, it flinches instead.\"",
        "SelfLoops" : 0,
        "SUID" : 399,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : 2257.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "397",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"User attacks first, foe flinches. Only usable on first turn.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"User attacks first, foe flinches. Only usable on first turn.\"",
        "SelfLoops" : 0,
        "SUID" : 397,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : 2257.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "395",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Power doubles if user is burned, poisoned, or paralyzed.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Power doubles if user is burned, poisoned, or paralyzed.\"",
        "SelfLoops" : 0,
        "SUID" : 395,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : 2257.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "393",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Reduces opponent's HP to same as user's.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Reduces opponent's HP to same as user's.\"",
        "SelfLoops" : 0,
        "SUID" : 393,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : 2257.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "391",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Dives underwater on first turn, attacks on second turn.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Dives underwater on first turn, attacks on second turn.\"",
        "SelfLoops" : 0,
        "SUID" : 391,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : 2257.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "389",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Opponent's item is stolen by the user.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Opponent's item is stolen by the user.\"",
        "SelfLoops" : 0,
        "SUID" : 389,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : 2357.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "387",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Breaks through Reflect and Light Screen barriers.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Breaks through Reflect and Light Screen barriers.\"",
        "SelfLoops" : 0,
        "SUID" : 387,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : 2357.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "385",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Springs up on first turn, attacks on second. May paralyze opponent.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Springs up on first turn, attacks on second. May paralyze opponent.\"",
        "SelfLoops" : 0,
        "SUID" : 385,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : 2357.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "383",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"High critical hit ratio. May burn opponent.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"High critical hit ratio. May burn opponent.\"",
        "SelfLoops" : 0,
        "SUID" : 383,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : 2357.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "381",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"User attacks last, but ignores Accuracy and Evasiveness.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"User attacks last, but ignores Accuracy and Evasiveness.\"",
        "SelfLoops" : 0,
        "SUID" : 381,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : 2357.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "379",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Hits thrice in one turn at increasing power.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Hits thrice in one turn at increasing power.\"",
        "SelfLoops" : 0,
        "SUID" : 379,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : 2357.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "377",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Also steals opponent's held item.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Also steals opponent's held item.\"",
        "SelfLoops" : 0,
        "SUID" : 377,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : 2357.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "375",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"May raise user's Defense.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"May raise user's Defense.\"",
        "SelfLoops" : 0,
        "SUID" : 375,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : 2457.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "373",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Doubles in power each turn for 5 turns.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Doubles in power each turn for 5 turns.\"",
        "SelfLoops" : 0,
        "SUID" : 373,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : 2457.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "371",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Power increases with higher Friendship.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Power increases with higher Friendship.\"",
        "SelfLoops" : 0,
        "SUID" : 371,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : 2457.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "369",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Raises user's Speed and removes entry hazards and trap move effects.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Raises user's Speed and removes entry hazards and trap move effects.\"",
        "SelfLoops" : 0,
        "SUID" : 369,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : 2457.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "367",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Double power if the opponent is switching out.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Double power if the opponent is switching out.\"",
        "SelfLoops" : 0,
        "SUID" : 367,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : 2457.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "365",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Either deals damage or heals.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Either deals damage or heals.\"",
        "SelfLoops" : 0,
        "SUID" : 365,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : 2457.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "363",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"May raise user's Attack.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"May raise user's Attack.\"",
        "SelfLoops" : 0,
        "SUID" : 363,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : 2457.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "361",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Hits with random power.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Hits with random power.\"",
        "SelfLoops" : 0,
        "SUID" : 361,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : 2557.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "359",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Power increases each turn.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Power increases each turn.\"",
        "SelfLoops" : 0,
        "SUID" : 359,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : 2557.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "357",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Power decreases with higher Friendship.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Power decreases with higher Friendship.\"",
        "SelfLoops" : 0,
        "SUID" : 357,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : 2557.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "355",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"The lower the user's HP, the higher the power.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"The lower the user's HP, the higher the power.\"",
        "SelfLoops" : 0,
        "SUID" : 355,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : 2557.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "353",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Ignores Accuracy and Evasiveness.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Ignores Accuracy and Evasiveness.\"",
        "SelfLoops" : 0,
        "SUID" : 353,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : 2557.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "351",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Confuses opponent.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Confuses opponent.\"",
        "SelfLoops" : 0,
        "SUID" : 351,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : 2557.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "349",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Each Pokémon in user's party attacks.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Each Pokémon in user's party attacks.\"",
        "SelfLoops" : 0,
        "SUID" : 349,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : 2557.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "347",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Hits twice in one turn. May poison opponent.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Hits twice in one turn. May poison opponent.\"",
        "SelfLoops" : 0,
        "SUID" : 347,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : 2657.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "345",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"User attacks for 2-3 turns but then becomes confused.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"User attacks for 2-3 turns but then becomes confused.\"",
        "SelfLoops" : 0,
        "SUID" : 345,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : 2657.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "343",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Always takes off half of the opponent's HP.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Always takes off half of the opponent's HP.\"",
        "SelfLoops" : 0,
        "SUID" : 343,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : 2657.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "341",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Only usable when all PP are gone. Hurts the user.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Only usable when all PP are gone. Hurts the user.\"",
        "SelfLoops" : 0,
        "SUID" : 341,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : 2657.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "339",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Charges on first turn, attacks on second. May cause flinching. High critical hit ratio.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Charges on first turn, attacks on second. May cause flinching. High critical hit ratio.\"",
        "SelfLoops" : 0,
        "SUID" : 339,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : 2657.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "337",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Raises Defense on first turn, attacks on second.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Raises Defense on first turn, attacks on second.\"",
        "SelfLoops" : 0,
        "SUID" : 337,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : 2657.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "335",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Inflicts damage equal to user's level.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Inflicts damage equal to user's level.\"",
        "SelfLoops" : 0,
        "SUID" : 335,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : 2657.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "333",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Raises user's Attack when hit.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Raises user's Attack when hit.\"",
        "SelfLoops" : 0,
        "SUID" : 333,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : 2757.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "331",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"May poison the opponent.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"May poison the opponent.\"",
        "SelfLoops" : 0,
        "SUID" : 331,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : 2757.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "329",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Money is earned after the battle.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Money is earned after the battle.\"",
        "SelfLoops" : 0,
        "SUID" : 329,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : 2757.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "327",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"The heavier the opponent, the stronger the attack.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"The heavier the opponent, the stronger the attack.\"",
        "SelfLoops" : 0,
        "SUID" : 327,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : 2757.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "325",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"User recovers half the HP inflicted on opponent.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"User recovers half the HP inflicted on opponent.\"",
        "SelfLoops" : 0,
        "SUID" : 325,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : 2757.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "323",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"May freeze opponent.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"May freeze opponent.\"",
        "SelfLoops" : 0,
        "SUID" : 323,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : 2757.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "321",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"If it misses, the user loses half their HP.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"If it misses, the user loses half their HP.\"",
        "SelfLoops" : 0,
        "SUID" : 321,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : 2757.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "319",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Flies up on first turn, attacks on second turn.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Flies up on first turn, attacks on second turn.\"",
        "SelfLoops" : 0,
        "SUID" : 319,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : 2857.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "317",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"One-Hit-KO, if it hits.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"One-Hit-KO, if it hits.\"",
        "SelfLoops" : 0,
        "SUID" : 317,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : 2857.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "315",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"May burn opponent.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"May burn opponent.\"",
        "SelfLoops" : 0,
        "SUID" : 315,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : 2857.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "313",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"User faints.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"User faints.\"",
        "SelfLoops" : 0,
        "SUID" : 313,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : 2857.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "311",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Power is doubled if opponent is underground from using Dig.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Power is doubled if opponent is underground from using Dig.\"",
        "SelfLoops" : 0,
        "SUID" : 311,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : 2857.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "309",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"User receives recoil damage.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"User receives recoil damage.\"",
        "SelfLoops" : 0,
        "SUID" : 309,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : 2857.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "307",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"May confuse opponent.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"May confuse opponent.\"",
        "SelfLoops" : 0,
        "SUID" : 307,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : 2857.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "305",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Digs underground on first turn, attacks on second. Can also escape from caves.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Digs underground on first turn, attacks on second. Can also escape from caves.\"",
        "SelfLoops" : 0,
        "SUID" : 305,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : 2957.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "303",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"High critical hit ratio.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"High critical hit ratio.\"",
        "SelfLoops" : 0,
        "SUID" : 303,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : 2957.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "301",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"When hit by a Physical Attack, user strikes back with 2x power.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"When hit by a Physical Attack, user strikes back with 2x power.\"",
        "SelfLoops" : 0,
        "SUID" : 301,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : 2957.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "299",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"May lower opponent's Speed by one stage.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"May lower opponent's Speed by one stage.\"",
        "SelfLoops" : 0,
        "SUID" : 299,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : 2957.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "297",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Hits twice in one turn.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Hits twice in one turn.\"",
        "SelfLoops" : 0,
        "SUID" : 297,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : 2957.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "295",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"May paralyze opponent.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"May paralyze opponent.\"",
        "SelfLoops" : 0,
        "SUID" : 295,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : 2957.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "293",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Traps opponent, damaging them for 4-5 turns.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Traps opponent, damaging them for 4-5 turns.\"",
        "SelfLoops" : 0,
        "SUID" : 293,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : 2957.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "291",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"User takes damage for two turns then strikes back double.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"User takes damage for two turns then strikes back double.\"",
        "SelfLoops" : 0,
        "SUID" : 291,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : 3057.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "289",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Hits 2-5 times in one turn.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Hits 2-5 times in one turn.\"",
        "SelfLoops" : 0,
        "SUID" : 289,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : 3057.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "287",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Always results in a critical hit.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Always results in a critical hit.\"",
        "SelfLoops" : 0,
        "SUID" : 287,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : 3057.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "285",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Power increases when player's bond is stronger.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Power increases when player's bond is stronger.\"",
        "SelfLoops" : 0,
        "SUID" : 285,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : 3057.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "283",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Lowers opponent's Attack.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Lowers opponent's Attack.\"",
        "SelfLoops" : 0,
        "SUID" : 283,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : 3057.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "281",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Prevents use of sound moves for two turns.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Prevents use of sound moves for two turns.\"",
        "SelfLoops" : 0,
        "SUID" : 281,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : 3057.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "279",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Ignores the target's ability.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Ignores the target's ability.\"",
        "SelfLoops" : 0,
        "SUID" : 279,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : 3057.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "277",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Driven by frustration, the user attacks the target. If the user's previous move has failed, the power of this move doubles.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Driven by frustration, the user attacks the target. If the user's previous move has failed, the power of this move doubles.\"",
        "SelfLoops" : 0,
        "SUID" : 277,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : 3157.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "275",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Lycanroc-exclusive Z-Move.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Lycanroc-exclusive Z-Move.\"",
        "SelfLoops" : 0,
        "SUID" : 275,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : 3157.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "273",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Prevents the opponent from switching out.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Prevents the opponent from switching out.\"",
        "SelfLoops" : 0,
        "SUID" : 273,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : 3157.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "271",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"The user hides in the target's shadow, steals the target's stat boosts, and then attacks.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"The user hides in the target's shadow, steals the target's stat boosts, and then attacks.\"",
        "SelfLoops" : 0,
        "SUID" : 271,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : 3157.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "269",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Marshadow-exclusive Z-Move.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Marshadow-exclusive Z-Move.\"",
        "SelfLoops" : 0,
        "SUID" : 269,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : 3157.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "267",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Charges on first turn, attacks on second.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Charges on first turn, attacks on second.\"",
        "SelfLoops" : 0,
        "SUID" : 267,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : 3157.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "265",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"The user stabs the target with a sharp horn. This attack never misses.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"The user stabs the target with a sharp horn. This attack never misses.\"",
        "SelfLoops" : 0,
        "SUID" : 265,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : 3157.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "263",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Burns the opponent.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Burns the opponent.\"",
        "SelfLoops" : 0,
        "SUID" : 263,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : 3257.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "261",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Decidueye-exclusive Z-Move.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Decidueye-exclusive Z-Move.\"",
        "SelfLoops" : 0,
        "SUID" : 261,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : 3257.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "259",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Solgaleo-exclusive Z-Move.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Solgaleo-exclusive Z-Move.\"",
        "SelfLoops" : 0,
        "SUID" : 259,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : 3257.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "257",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Drains HP from opponent each turn.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Drains HP from opponent each turn.\"",
        "SelfLoops" : 0,
        "SUID" : 257,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : 3257.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "255",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Snorlax-exclusive Normal type Z-Move.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Snorlax-exclusive Normal type Z-Move.\"",
        "SelfLoops" : 0,
        "SUID" : 255,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : 3257.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "253",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"The user bites the target with its psychic capabilities. This can also destroy Light Screen and Reflect.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"The user bites the target with its psychic capabilities. This can also destroy Light Screen and Reflect.\"",
        "SelfLoops" : 0,
        "SUID" : 253,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : 3257.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "251",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"The user boasts its strength and attacks the target. The more the user's stats are raised, the greater the move's power.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"The user boasts its strength and attacks the target. The more the user's stats are raised, the greater the move's power.\"",
        "SelfLoops" : 0,
        "SUID" : 251,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : 3257.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "249",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Changes Normal-type moves to Electric-type moves.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Changes Normal-type moves to Electric-type moves.\"",
        "SelfLoops" : 0,
        "SUID" : 249,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : 3357.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "247",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Type matches Memory item held.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Type matches Memory item held.\"",
        "SelfLoops" : 0,
        "SUID" : 247,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : 3357.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "245",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Incineroar-exclusive Z-Move.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Incineroar-exclusive Z-Move.\"",
        "SelfLoops" : 0,
        "SUID" : 245,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : 3357.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "243",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"The user makes a lunge at the target, attacking with full force. This also lowers the target's Attack stat.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"The user makes a lunge at the target, attacking with full force. This also lowers the target's Attack stat.\"",
        "SelfLoops" : 0,
        "SUID" : 243,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : 3357.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "241",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"May lower opponent's Defense.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"May lower opponent's Defense.\"",
        "SelfLoops" : 0,
        "SUID" : 241,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : 3357.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "239",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Mimikyu-exclusive Z-Move.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Mimikyu-exclusive Z-Move.\"",
        "SelfLoops" : 0,
        "SUID" : 239,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : 3357.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "237",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Strikes opponent with leaves.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Strikes opponent with leaves.\"",
        "SelfLoops" : 0,
        "SUID" : 237,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : 3357.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "235",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"The user swings and hits with its strong, heavy fist. It lowers the user's Speed, however.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"The user swings and hits with its strong, heavy fist. It lowers the user's Speed, however.\"",
        "SelfLoops" : 0,
        "SUID" : 235,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : 3457.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "233",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"The user fiercely attacks the target using its entire body.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"The user fiercely attacks the target using its entire body.\"",
        "SelfLoops" : 0,
        "SUID" : 233,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : 3457.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "231",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"May cause flinching.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"May cause flinching.\"",
        "SelfLoops" : 0,
        "SUID" : 231,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : 3457.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "229",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Although this move has great power, it only works the first turn the user is in battle.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Although this move has great power, it only works the first turn the user is in battle.\"",
        "SelfLoops" : 0,
        "SUID" : 229,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : 3457.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "227",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"The user strikes the target with a burning lash. This also lowers the target's Defense stat.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"The user strikes the target with a burning lash. This also lowers the target's Defense stat.\"",
        "SelfLoops" : 0,
        "SUID" : 227,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : 3457.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "225",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"The user uses its body like a hammer to attack the target and inflict damage.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"The user uses its body like a hammer to attack the target and inflict damage.\"",
        "SelfLoops" : 0,
        "SUID" : 225,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : 3457.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "223",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Hits twice in one turn; may cause flinching.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Hits twice in one turn; may cause flinching.\"",
        "SelfLoops" : 0,
        "SUID" : 223,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : 3457.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "221",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Ignores opponent's stat changes.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Ignores opponent's stat changes.\"",
        "SelfLoops" : 0,
        "SUID" : 221,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : 3557.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "219",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Pikachu-exclusive Z-Move.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Pikachu-exclusive Z-Move.\"",
        "SelfLoops" : 0,
        "SUID" : 219,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : 3557.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "217",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"The user swings its body around violently to inflict damage on everything in its vicinity.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"The user swings its body around violently to inflict damage on everything in its vicinity.\"",
        "SelfLoops" : 0,
        "SUID" : 217,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : 3557.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "215",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"The user first heats up its beak, and then it attacks the target. Making direct contact with the Pokémon while it's heating up its beak results in a burn.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"The user first heats up its beak, and then it attacks the target. Making direct contact with the Pokémon while it's heating up its beak results in a burn.\"",
        "SelfLoops" : 0,
        "SUID" : 215,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : 3557.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "213",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"The user entangles the target with its anchor chain while attacking. The target becomes unable to flee.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"The user entangles the target with its anchor chain while attacking. The target becomes unable to flee.\"",
        "SelfLoops" : 0,
        "SUID" : 213,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : 3557.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "211",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"User attacks first.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"User attacks first.\"",
        "SelfLoops" : 0,
        "SUID" : 211,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : 3557.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "209",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Opponent cannot flee or switch.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Opponent cannot flee or switch.\"",
        "SelfLoops" : 0,
        "SUID" : 209,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : 3557.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "207",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Makes Flying-type Pokémon vulnerable to Ground moves.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Makes Flying-type Pokémon vulnerable to Ground moves.\"",
        "SelfLoops" : 0,
        "SUID" : 207,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : 3657.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "205",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Hits all adjacent opponents.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Hits all adjacent opponents.\"",
        "SelfLoops" : 0,
        "SUID" : 205,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : 3657.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "203",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Raises Attack.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Raises Attack.\"",
        "SelfLoops" : 0,
        "SUID" : 203,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : 3657.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "201",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"May lower opponent's Attack.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"May lower opponent's Attack.\"",
        "SelfLoops" : 0,
        "SUID" : 201,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : 3657.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "199",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Disappears on first turn, attacks on second. Can strike through Protect/Detect.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Disappears on first turn, attacks on second. Can strike through Protect/Detect.\"",
        "SelfLoops" : 0,
        "SUID" : 199,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : 3657.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "197",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Hits all adjacent Pokémon.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Hits all adjacent Pokémon.\"",
        "SelfLoops" : 0,
        "SUID" : 197,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : 3657.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "195",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Paralyzes opponent.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Paralyzes opponent.\"",
        "SelfLoops" : 0,
        "SUID" : 195,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 300.56497175141243,
        "y" : 3657.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "193",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"\"",
        "SelfLoops" : 0,
        "SUID" : 193,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -299.43502824858757,
        "y" : 3757.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "191",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Lowers user's Defense. Can strike through Protect/Detect.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Lowers user's Defense. Can strike through Protect/Detect.\"",
        "SelfLoops" : 0,
        "SUID" : 191,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -199.43502824858757,
        "y" : 3757.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "189",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Always leaves opponent with at least 1 HP.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Always leaves opponent with at least 1 HP.\"",
        "SelfLoops" : 0,
        "SUID" : 189,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : -99.43502824858757,
        "y" : 3757.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "187",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Deals Fighting and Flying type damage.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Deals Fighting and Flying type damage.\"",
        "SelfLoops" : 0,
        "SUID" : 187,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 0.5649717514124291,
        "y" : 3757.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "185",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Drastically raises user's Attack if target is KO'd.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Drastically raises user's Attack if target is KO'd.\"",
        "SelfLoops" : 0,
        "SUID" : 185,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 100.56497175141243,
        "y" : 3757.062146892655
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "183",
        "ClosenessCentrality" : 0.0,
        "Eccentricity" : 0,
        "Degree" : 0,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "Radiality" : "Infinity",
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "\"Lowers user's Defense and Special Defense.\"",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 0,
        "name" : "\"Lowers user's Defense and Special Defense.\"",
        "SelfLoops" : 0,
        "SUID" : 183,
        "IsSingleNode" : true,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 0.0,
        "selected" : false,
        "NeighborhoodConnectivity" : 0.0
      },
      "position" : {
        "x" : 200.56497175141243,
        "y" : 3757.062146892655
      },
      "selected" : false
    } ],
    "edges" : [ ]
  }
}}